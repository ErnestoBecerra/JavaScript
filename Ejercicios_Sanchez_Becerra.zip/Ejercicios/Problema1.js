console.log( "PROGRAMA 1" );
let cadena;
function stringtoArray(cadena){
    console.log(cadena.split(' '));
}

cadena = prompt("Introduzca una cadena: ", " ");
console.log(stringtoArray(cadena));


